import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { StyleSheet, Text, SafeAreaView } from 'react-native';
import HomePage from "./HomePage";

export default class App extends React.Component{
  render(){
    return (
        <SafeAreaView style={styles.container}>
          <HomePage />
        </SafeAreaView>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#222',
    minHeight: "100%",
    marginTop: "8%"
  },
});

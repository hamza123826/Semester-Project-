import React from "react";
import Dialog, {
    DialogTitle,
    DialogContent,
    DialogFooter,
    DialogButton,
    SlideAnimation,
    ScaleAnimation,
} from 'react-native-popup-dialog';

import { StyleSheet, Text, View, SafeAreaView, TouchableOpacity,TextInput } from "react-native";
class CreateTodo extends React.Component {
    state = {
        viewVisible: false,
        data: {}
    }
    onChange = (fieldName, fieldValue) => {
        this.setState({ data: { ...this.state.data, [fieldName]: fieldValue } })
    }
    render() {
        const { onChange } = this;
        const { name, description } = this.state.data;
        return (
            <SafeAreaView>
                    <TouchableOpacity 
                        style={styles.buttonStyle}
                        onPress={() => {this.setState({viewVisible: true})}}
                    >
                        <Text style={styles.buttonTextStyle}>+</Text>
                    </TouchableOpacity>
                    <Dialog 
                        visible = {this.state.viewVisible}
                        onDismiss = {
                            () => {
                                this.setState({viewVisible: false})
                            }
                        }
                        dialogTitle={
                            <DialogTitle
                                title="Add to do"
                                hasTitleBar= {false}
                                align="left"
                                style={{
                                    backgroundColor: "#fff",
                                  }}
                                textStyle={
                                    {
                                        "fontSize": 22
                                    }
                                }
                            />
                        }
                        rounded
                        width = {0.9}
                        actionsBordered
                        footer={
                            <DialogFooter>
                              <DialogButton
                                text="CANCEL"
                                bordered
                                onPress={() => {
                                  this.setState({viewVisible: false});
                                }}
                                key="button-1"
                              />
                              <DialogButton
                                text="Add"
                                bordered
                                onPress={() => {
                                  this.setState({viewVisible: false});
                                  this.props.addToDo(this.state.data);
                                }}
                                key="button-2"
                              />
                            </DialogFooter>
                          }

                    >
                        <DialogContent
                            style={{
                                backgroundColor: "#fff"
                            }}
                            >
                            <View style={
                                {
                                    marginBottom: 5
                                }
                            }>
                            <Text style={styles.label}>Title:</Text>
                            <TextInput placeholder="Enter Name Of Task"
                            style={styles.input}
                            defaultValue={name}
                            onChangeText={text => onChange("name", text)}
                            />
                            </View>
                            <View style={
                                {
                                    marginBottom: 5
                                }
                            }>
                            <Text style={styles.label}>Description:</Text>
                            <TextInput 
                            placeholder="Enter Description Of Task"
                            style={styles.input}
                            multiline={true}
                            numberOfLines={3}
                            defaultValue={description}
                            onChangeText={text => onChange("description", text)}
                            />
                            </View>
                        </DialogContent>
                    </Dialog>
                </SafeAreaView>
        );
    };
};

const styles = StyleSheet.create({
    buttonStyle: {
        textAlign: "center",
        padding: 10,
        backgroundColor: '#ffa500',
        color: 'white',
        width: 70,
        height: 70,
        borderRadius: 50,
        position: "absolute",
        bottom: 100,
        right: 10,
        zIndex: 1
    },
    buttonTextStyle: {
        fontSize: 35,
        textAlign: "center"
    },
    input: {
        paddingVertical: 1,
        paddingHorizontal: 5,
        marginVertical: 5,
        fontSize: 18,
        borderWidth: 1,
        borderColor: "#ccc",
        borderStyle: "solid",
        borderRadius: 5
    },
    label: {
        fontSize: 18,
        fontWeight: "600"
    }
});


export default CreateTodo;
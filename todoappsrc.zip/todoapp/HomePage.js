import React, { useState } from "react";
import { StyleSheet, Text, View, FlatList, TouchableHighlight,ScrollView} from "react-native";
import CreateTodo from './CreateTodo';
import AsyncStorage from '@react-native-async-storage/async-storage';

class HomePage extends React.Component {
    constructor(props) {
      super(props);
    
      this.state = {
        todos: []
      };
    }
    componentDidMount() {
        this.fetchTodo();
    }
    addToDo = async (data) => {
        try{
            var todos = this.state.todos;
            await todos.push(data);
            await AsyncStorage.setItem("todos", JSON.stringify(todos));
            this.fetchTodo();
        } catch (e){
            console.log(e)
        }
    };
    fetchTodo = async () => {
        try{
            var todos = await AsyncStorage.getItem("todos");
            if(todos !== null) {
                this.setState({todos: JSON.parse(todos)})
            } else{
                this.setState({todos: []})
            }
        }catch(e){
            console.log(e);
        }
    }
    deleteTodo = async (todoId) => {
        try{
            var todos = this.state.todos;
            await todos.splice(todoId, 1);
            await AsyncStorage.setItem("todos", JSON.stringify(todos));
            this.fetchTodo();
        } catch (e){
            console.log(e)
        }
    }
    markDone = async (todoId) => {
        try{
            var todos = this.state.todos;
            todos[todoId].markDone = await true;
            await AsyncStorage.setItem("todos", JSON.stringify(todos));
            this.fetchTodo();
        } catch (e){
            console.log(e)
        }
    }
    markUnDone = async(todoId) => {
        try{
            var todos = this.state.todos;
            todos[todoId].markDone = await false;
            await AsyncStorage.setItem("todos", JSON.stringify(todos));
            this.fetchTodo();
        } catch (e){
            console.log(e)
        }
    }
    updateToDo = (data) => {
        
    }
    render() {
        const {editing, todos} = this.state;
        const {deleteTodo, markDone, markUnDone, updateToDo} = this;
        const renderItem = ({ item, index }) => (
            <View style={item.markDone ? styles.listGreen:styles.list} key={index}>
                <Text style={styles.todoName}>{item.name}</Text>
                <Text style={styles.toDoDescription}>{item.description}</Text>
                <View style={styles.btnContainer}>
                    <TouchableHighlight 
                            style={styles.deleteBtn}
                            onPress={() => {deleteTodo(index)}}
                        >
                        <Text style={styles.deleteBtnTextStyle}>Delete</Text>
                    </TouchableHighlight>
                    {item.markDone ?
                        <TouchableHighlight 
                                style={styles.markUnDoneBtn}
                                onPress={() => {markUnDone(index)}}
                            >
                            <Text style={styles.markUnDoneBtnTextStyle}>Mark As Un-done</Text>
                        </TouchableHighlight>
                        :
                        <TouchableHighlight 
                                style={styles.markDoneBtn}
                                onPress={() => {markDone(index)}}
                            >
                            <Text style={styles.markDoneBtnTextStyle}>Mark As Done</Text>
                        </TouchableHighlight>
                    }
                </View>
            </View>
        );
        return (
            <View style={{height: "100%", paddingBottom: 100}}>
            <View>
                    <Text 
                        style={styles.header}
                    >My to do</Text>
            </View>
            <ScrollView style={
                {
                    minHeight: "100%"
                }
            }>
                        {this.state.todos.length > 0 ?
                            (
                                    todos.map(function(item, index) {
                                        return renderItem({item: item, index: index})
                                    })
                                )
                            : 
                            (
                                <View>
                                    <Text style={styles.alert1}>No tasks yet</Text>
                                    <Text style={styles.alert2}>Please click the plus button to create</Text>
                                </View>
                            )
                    }
                </ScrollView>
                <CreateTodo addToDo={this.addToDo} />
            </View>
        );
    };
};


const styles = StyleSheet.create({
    header: {
        backgroundColor: "#0053ff",
        color: "#fff",
        textAlign: "center",
        paddingVertical: 15,
        fontSize: 22
    },
    list: {
        margin: 15,
        backgroundColor: "#fff",
        paddingVertical: 5,
        paddingHorizontal: 10,
        borderRadius: 5
    },
    listGreen: {
        margin: 15,
        backgroundColor: "#00aa00",
        paddingVertical: 5,
        paddingHorizontal: 10
    },
    alert1: {
        paddingTop: "35%",
        color: "#fff",
        "textAlign": "center",
        "fontSize": 20
    },
    alert2: {
        paddingTop: "5%",
        color: "#fff",
        "textAlign": "center",
        "fontSize": 22,
        "fontWeight": "600"
    },
    todoName: {
        fontSize: 22,
        fontWeight: "900"
    },
    toDoDescription: {
        fontSize: 18,
        fontWeight: "200",
        color: "#555"
    },
    deleteBtn: {
        backgroundColor: "#f00",
        borderRadius: 5,
        width: "28%"
    },
    deleteBtnTextStyle:{
        paddingHorizontal: 20,
        paddingVertical: 10,
        textAlign: "center",
        fontSize: 18
    },
    markDoneBtn: {
        backgroundColor: "#00ff00",
        borderRadius: 5,
        width: "50%"
    },
    markDoneBtnTextStyle:{
        paddingHorizontal: 20,
        paddingVertical: 10,
        textAlign: "center",
        fontSize: 18
    },
    markUnDoneBtn: {
        backgroundColor: "#fff",
        borderRadius: 5,
        width: "60%"
    },
    markUnDoneBtnTextStyle:{
        paddingHorizontal: 20,
        paddingVertical: 10,
        textAlign: "center",
        fontSize: 18
    },
    btnContainer: {
        marginVertical: 10,
        "flexDirection": "row",
        justifyContent: "space-between"
    }
});

export default HomePage;